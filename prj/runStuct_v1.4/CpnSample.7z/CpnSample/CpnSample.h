/**************************************************************************
* Copyright    : Copyright(C), 2019, pxf, person.
* File name    : CpnSample.h
* Author       : pxf
* Version      : v1.0
* Created on   : 2020/01/05 09:21:14
* Description  : CpnSample�༰�ӿ�����ͷ�ļ�
* Others       : 
* History      : 200105 pxf ���ν���
***************************************************************************/

#ifndef CPNSAMPLE_H_
#define CPNSAMPLE_H_

/*ͷ�ļ�����*/
#include "../oopc_v1.02/oopc.h"

/***********************************************************
* �ӿڶ���
***********************************************************/
/*�ӿ�����
***********************************************/
//INF(get){
//  uint16(*get)(void);
//};
//TODO

/***********************************************************
* CpnSample�ඨ��
***********************************************************/
/*CpnSample������
***********************************************/
CL(CpnSample){
    hCpnSample self;
    hCpnSample (*init)(hCpnSample cthis);

    // CpnSample�����
    //TODO

    // CpnSample�๦�ܺ���
    void (*run)(hCpnSample cthis);
    void (*update)(hCpnSample cthis);
    void (*excute)(hCpnSample cthis);
    //TODO
};

#endif /*CPNSAMPLE_H_*/

/**************************** Copyright(C) pxf ****************************/
