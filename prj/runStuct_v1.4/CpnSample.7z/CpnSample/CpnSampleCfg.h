/**************************************************************************
* Copyright    : Copyright(C), 2019, pxf, person.
* File name    : CpnSampleCfg.h
* Author       : pxf
* Version      : v1.0
* Created on   : 2020/01/05 09:21:14
* Description  : 
* Others       : 
* History      : 200105 pxf ���ν���
***************************************************************************/

#ifndef CPNSAMPLECFG_H_
#define CPNSAMPLECFG_H_

/*ͷ�ļ�����*/

/*���� : CpnSampleCfg()
* ���� : ��
* ��� : ��
* ���� : ��
***********************************************/
void CpnSampleCfg(void);

#endif /*CPNSAMPLECFG_H_*/

/**************************** Copyright(C) pxf ****************************/
